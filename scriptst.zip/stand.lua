--[[ For any template shares, please make sure to include a list of the abilities inside the template as follows :
Summon stand = Summon! /e q
Desummon stand = Desummon! /e w
Rejoin! / Rejoins
Leave! / Leaves
Ora! / barrages infront of you
Aura! / goes below u and begins hitting in a circle
Caura! / goes above you and begins dropping cash
Bring! user / Brings person
Kill! user / Loopkills the person
AuraC! / Goes below u and Hits in charge attack
Stab! / attacks players
Save! / Saves the owner
Mimic! / mimics the owner
CAura! / works like Aura!
]]--

--/ Beginner links are provided in-case your unsure what you're doing. / Please refer to template sharing & ability sharing in https://discord.com/invite/g4kFtuS5G6 for already made templates and abilities.
getgenv().Settings = {
    ['Made By JoJo#2494'] = {
        OWNER = "KingErik2", --/ Stand owner username.
        STANDS = {"a2qi", ""}, --/ List of your stand accounts (if you have more than one you can add more usernames to the table).
        FPS = 45, --/ Will control FPS can improve the overall performance on both instances when set to lower.
        PERFORMANCE = false, --/ If set to true it'll significantly improve your overall FPS if you're struggling with performance.
        NOCLIP = {SynapseX = false, Offset = -3.05}, --/ Offset will control the height of normal noclip (keep unchanged unless you're using titan with a big character / SynapseX option).
        FACELESS = true, --/ If you want to remove your face.
        TRAILS = false, --/ If you want to remove the white trail when charge attacking.
        LEGS = false, --/ If set to true it'll remove your legs.
        ANTIFLING = true, --/ If set to true you can't get flinged nor can you fling anyone.
        TELEPORTMAIN = true, --/ Teleports to the stand user
        RANGE = 50, --/ Controls the melee reach range (50 is max).
        TITAN = {ENABLED = true, DEFAULT = true, TALL = false, WIDE = false, GODV3 = false}, --/ If enabled you will become a titan stand, if you enable god you need to execute before load for it to work (also can be used with titan disabled).
        FOLLOWANIM = {true, ID = 3541044388, SPEED = 0.25}, --/ If set to true will play the desired animation when moving (Default animation is heavily advised), SPEED will control the speed (Recommended is 0.25).
        AUTOPICKUPCASH = false, --/ If set to true will automatically pick up cash when you're near it & should not be used if your dropping cash.
    }
}
--[[
Developer notes : 
- I will not provide template abilities for this current release and probably not for foreseeable future, so it is a MUST that you somewhat read this tutorial / guide regarding this stand creator.
- You are directly responsible and held accountable for any clips/bans/etc.. You are advised to not use this script on accounts that you care about.
- If you have any questions or concerns regarding this script, please contact me (https://discord.com/invite/g4kFtuS5G6) at #support.
]]--

--/ DOCUMENTATION OF THE FUNCTIONS \--

--/ 1. Create('COMMANDNAMEHERE', function() --/ This will create an chat command / replace COMMANDNAME inside the brackets with your desired command name.
--/ 2. CreateAction('LOOPNAMEHERE', function() --/ This will create an action this should be placed before (1).
--/ 3. CreateTargetAbility("COMMANDNAMEHERE", function() --/ This will use an command on a target you choose / eg..(Attack! Bacon)
--/ 4. CreateLoop("LOOPNAMEHERE", function() --/  This will begin looping the arguments specified until stopped (5).
--/ 5. StopLoop("LOOPNAMEHERE") --/ This will stop the specified loop (4).
--/ 6. Stand.Action = "LOOPNAMEHERE" --/ This will begin the specified loop/action that you have created (Refer to 2). Stand.Action = "" will essentially stop the action.
--/ 7. Play(ID, true) --/ This will begin playing the specified audio in the first argument, The second argument true/false + If the second argument is set to false it'll begin looping the audio.
--/ 8. Stop() --/ This will stop any audios from playing.
--/ 9. AnimPlay(ID,SPEED) --/ This will begin playing the specified animation (ONLY DH / ROBLOX ANIMATIONS), SPEED will control the animationspeed (Default is 1).
--/ 10. AnimStop(ID,SPEED) --/ This will stop playing the specified animation, SPEED will control the stopping speed (Default is 1).
--/ 11. Chat("TEXTGOESHERE") --/ Will chat the specified text in the first argument (stand cry / eg.. following you master).
--/ 12. Buy.Item() --/ Will buy the specified melee (make sure you have enough cash). eg.. Buy.Knife(), Buy.Bat(), Buy.StopSign(), Buy.Shovel(), Buy.Pencil(), Buy.Nunchucks(), Buy.SledgeHammer(), Buy.Grenade(), Buy.Flashbang(), Buy.Boxing(), Buy.Default().
--/ 13. Hit(true) --/ If the first argument is set to true it'll do a charge attack + If the first argument is set to false it'll do a quick punch.
--/ 14. Crew(true,ID) --/ If the first argument is set true it'll join the crew specified(ID) + If the first argument is set to false it'll leave any current crew.
--/ 15. DropMoney(Amount) --/ This will drop the amount of money specified.
--/ 16. GetNearest() --/ This will get the nearest enemy player.
--/ 17. Equip(Tool) --/ This will equip the specific tool eg.. "Combat", "Wallet", [Knife], [Bat], [StopSign], [Shovel], [Pencil], [Nunchucks], [SledgeHammer], [Grenade], [Flashbang] --/ In-case your item is not on this list use darkdex.
--/ 18. Unequip() --/ This will unequip any currently equipped tools.

--[[ -- IGNORE THIS LINE & REMOVE CONTENT INSIDE THE BRACKETS IF YOU KNOW WHAT YOU'RE DOING.

--/ DOCUMENTATION OF EXAMPLES \--  

--/ 1. This will print the username of the target nearest to the owner.
Create("test", function()  --/ This will create an command (1). / Replace "test" inside the brackets with your desired command name.
    local Target = GetNearest() --/ Have an local Target = GetNearest() 
    print(Target.Name) --/ This will print the nearest player relative to you.
end) --/ Always remember end) on every command.

--/ 2. This will create an summon action / we will detail in this part what we during while it's summoned.
CreateAction("Summoned", function() --/ It's good practise to name the action in relation to what it is doing.
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(1,1.85,2.5) --/ This is the position of your stand relative to the owner. (xyz + edit the numbers) 
end) --/ Always remember end)

--/ 2,5. This is a chat command same as in (1), we will use this to trigger Summoned. (2)
Create("TUSK!", function()
    Stand.Action = "Summoned" --/ This is where we choose the action, we have made "Summoned" so we'll pick that.
end)

--/ 3. This is a command to stop the action. (2)
Create("Desummon!", function()
    Stand.Action = "" --/ We leave it as blank to stop the action. / You should not make a action with a blank name.
end)

--/ 4. This will make the stand teleport the target.
CreateTargetAbility("Goto!", function() 
    Stand.Action = ""  -- We will stop any current actions from interfering with this command.
    local Target = Stand.Target
    STAND.Character.HumanoidRootPart.CFrame = Target.Character.HumanoidRootPart.CFrame
end)

--/ 5. This will make the stand constantly attack around the player, Remember to always create the action before command (Refer to 2).
CreateAction("Aura", function() 
    local RANDOM = math.random(-10,10)
    STAND.Character.HumanoidRootPart.CFrame = CFrame.new(OWNER.Character.UpperTorso.Position.X + RANDOM, StandUser.Character.UpperTorso.Position.Y + RANDOM, OWNER.Character.UpperTorso.Position.Z + RANDOM)
    Hit(false)
end)  

--/ 5.5. Same as in (2.5).
Create("/e aura", function()
    Stand.Action = "Aura"
end)

--/ 6. This will purchase an item utilizing the buy function.
Create("Knife!", function()
    Buy.Knife() -- Refer to (10)
end)

]] -- IGNORE THIS LINE & REMOVE CONTENT INSIDE THE BRACKETS IF YOU KNOW WHAT YOU'RE DOING.

--/ STAND NAME & ABILITY IDEAS : \--
-- https://jojowiki.com/List_of_Stands

--/ STAND OUTFIT IDEAS : \--
-- https://www.roblox.com/games/9714571746/JoJos-Bizarre-Collection 

--/ JOJO SOUND EFFECTS : \--
-- https://www.roblox.com/develop/library?CatalogContext=2&Subcategory=16&CreatorName=jojoaudio&SortAggregation=5&LegendExpanded=true&Category=9
-- https://www.roblox.com/develop/library?CatalogContext=2&Subcategory=16&CreatorName=Tsuagon&SortAggregation=5&LegendExpanded=true&Category=9

--/ USEFUL SOURCES FOR BEGINNERS \--
-- https://developer.roblox.com/en-us/articles/Understanding-CFrame
-- https://developer.roblox.com/en-us/learn-roblox/coding-scripts
-- https://scriptinghelpers.org/
-- https://youtube.com/playlist?list=PLw1uWqQBDcgjKqFjPNgtVtBNx3xTGz-l7
--/----------------------------------------------------------------------------------------------\--
loadstring(game:HttpGet("https://raw.githubusercontent.com/JOJOGIO/STAND-FRAMEWORK/main/v.1.0.7"))()
--/---------------------------------------------------------------------------------------------\--/ CreateAction goes below this :
CreateAction("Summoned", function() 
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(1,1.85,2.5)
end)    

CreateAction("Barrage", function()
    if STAND.Character.HumanoidRootPart then
        if OWNER.Character.HumanoidRootPart then
            STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,0.85,-4.85)
            if STAND.Character:FindFirstChild("Combat") then
                Hit(false)
            else
                Equip("Combat")
                Hit(false)
            end
        end
    end
end)

Create("/e angry", function()
                                                        Chat("You have made me angry... 😡")
                                                        Play(146563959,true) -- u can change audio if u want
                                                        AnimPlay(2788838708,1)
                                                        Wait(2.7)
                                                        Stop()
                                                        Stand.Action = "Barrage"
                                                        end)

CreateAction("Aura", function() 
    wait()
    if OWNER.Character.Humanoid.FloorMaterial == Enum.Material.Air then 
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-20,0)
        Hit(false)
    elseif OWNER.Character.Humanoid.FloorMaterial ~= Enum.Material.Air then
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0 + math.random(-8.5,8.5),-10,0 + math.random(-8.5,8.5))
        Hit(false)
    else
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-25,0)
    end
end)   

CreateAction("AuraC", function() 
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,6,0)
    DropMoney(10000)
end)    

--/---------------------------------------------------------------------------------------------\--/ Create & CreateTargetAbility goes below this :
Create("TUSK!", function()
    pcall(function()
        game:GetService("RunService"):UnbindFromRenderStep("TARGETKILL")
		game:GetService("RunService"):UnbindFromRenderStep("GRAB")
        Stop()
    end)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.07)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.07)
    Stand.Action = "Summoned"
end)

Create("Desummon!", function()
    pcall(function()
        Stop()
    end)
    Stand.Action = "" 
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.09)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-100,0)
end)

Create("/e q", function()
    pcall(function()
        game:GetService("RunService"):UnbindFromRenderStep("TARGETKILL")
		game:GetService("RunService"):UnbindFromRenderStep("GRAB")
        Stop()
    end)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.05)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.05)
    Stand.Action = "Summoned"
end)

Create("/e w", function()
    pcall(function()
        Stop()
    end)
    Stand.Action = "" 
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-0.7,1.45)
    wait(0.075)
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,-100,0)
end)

Create("Rejoin!", function()
    game:GetService('TeleportService'):TeleportToPlaceInstance(game.PlaceId, game.JobId, STAND)
end)





CreateTargetAbility("Bring!", function()
    local Target = Stand.Target
    if Target then
    Stand.Action = ""
    game:GetService("RunService"):BindToRenderStep("GRAB", -1 , function()
    if Target and Target.Character and Target.Character:FindFirstChild("BodyEffects") and Target.Character.BodyEffects:FindFirstChild("K.O") then
    if Target.Character.BodyEffects["K.O"].Value == true then
        STAND.Character.HumanoidRootPart.CFrame = CFrame.new(Target.Character.UpperTorso.Position.X , Target.Character.UpperTorso.Position.Y + 1, Target.Character.UpperTorso.Position.Z )
        if STAND.Character.BodyEffects["Grabbed"].Value == nil then
            game:GetService("VirtualInputManager"):SendKeyEvent(true,"G",false,game)
        end
    end
    if Target.Character.BodyEffects["K.O"].Value == false then
        STAND.Character.HumanoidRootPart.CFrame = Target.Character.HumanoidRootPart.CFrame*CFrame.new(0,-6,0)
            if STAND.Character:FindFirstChildWhichIsA("Tool") then
                Hit(true)
            else
                Equip("Combat")
                Hit(true)
            end
        end
            if Target == nil or STAND.Character.BodyEffects["Grabbed"].Value ~= nil then
                game:GetService("RunService"):UnbindFromRenderStep("GRAB")
                Stand.Action = "Summoned"
            end
 	       end
		end)
	end
end)

CreateTargetAbility("Kill!", function()
    local Target = Stand.Target
    if Target then
    Stand.Action = ""
    game:GetService("RunService"):BindToRenderStep("TARGETKILL", -1 , function()
    if Target and Target.Character and Target.Character:FindFirstChild("BodyEffects") and Target.Character.BodyEffects:FindFirstChild("K.O") then
        if Target.Character.BodyEffects["K.O"].Value == true then
			STAND.Character.HumanoidRootPart.CFrame = CFrame.new(Target.Character.UpperTorso.Position.X , Target.Character.UpperTorso.Position.Y + 1, Target.Character.UpperTorso.Position.Z )
			game:GetService("ReplicatedStorage").MainEvent:FireServer("Stomp")
        else
            STAND.Character.HumanoidRootPart.CFrame = Target.Character.HumanoidRootPart.CFrame*CFrame.new(0,-10,0)
                if STAND.Character:FindFirstChildWhichIsA("Tool") then
                    Hit(true)
                else
                    Equip("Combat")
                    Hit(true)
                end
             end
          end
  	  end)
	end
end)


CreateAction("aura1", function() 
Target = GetNearest()
Range = 250
local x = math.random(-5,5)
local b = (OWNER.Character.UpperTorso.Position - Target.Character.UpperTorso.Position).Magnitude
    if Target and Target.Character and Target.Character:FindFirstChild("UpperTorso") and b < Range and Target.Character:FindFirstChild("BodyEffects") and Target.Character.BodyEffects:FindFirstChild("Defense") and Target.Character.BodyEffects:FindFirstChild("K.O") and Target.Character.BodyEffects.Attacking.Value == false and Target.Character.BodyEffects["K.O"].Value == false then
        STAND.Character.HumanoidRootPart.CFrame = CFrame.new(Target.Character.UpperTorso.Position.X + x, Target.Character.UpperTorso.Position.Y + x, Target.Character.UpperTorso.Position.Z + x)
        Hit(true) -- if true will charge
    else
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(1,1.85,2.5)
    end
end)  





CreateAction("Stab", function()
local t = GetNearest()
Range = 250
local x = math.random(-5,5)
local b = (OWNER.Character.UpperTorso.Position - t.Character.UpperTorso.Position).Magnitude
    if t and t.Character and t.Character:FindFirstChild("UpperTorso") and b < Range and t.Character:FindFirstChild("BodyEffects") and t.Character.BodyEffects:FindFirstChild("Defense") and t.Character.BodyEffects:FindFirstChild("K.O") and t.Character.BodyEffects.Attacking.Value == false and t.Character.BodyEffects["K.O"].Value == false then
        STAND.Character.HumanoidRootPart.CFrame = CFrame.new(t.Character.UpperTorso.Position.X + x, t.Character.UpperTorso.Position.Y + x, t.Character.UpperTorso.Position.Z + x)
        Hit(true) -- if true will charge
    else
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(1,1.85,2.5)
    end
end)



 CreateTargetAbility("save", function() -- Save Player lol isn't tested should work tho
    local Target = Stand.Target
    if Target then
        Stand.Action = "" 
        repeat wait()
            if Target.Character.BodyEffects["K.O"].Value == false then
                STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.UpperTorso.CFrame
            elseif Target.Character.BodyEffects["K.O"].Value == true then 
                wait(0.5)
                STAND.Character.HumanoidRootPart.CFrame = CFrame.new(Target.Character.UpperTorso.Position.X , Target.Character.UpperTorso.Position.Y +0.5, Target.Character.UpperTorso.Position.Z )
                wait(0.5)
                if STAND.Character.BodyEffects["Grabbed"].Value == nil then
                    wait(0.9)
                    game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", true)
                end
            end
            until Stand.Action == "Summoned" or Target == nil or not Target.Character.BodyEffects:FindFirstChild("K.O") or not Target.Character.BodyEffects:FindFirstChild("Defense") or STAND.Character.BodyEffects["Grabbed"].Value ~= nil 
            STAND.Character.HumanoidRootPart.CFrame = CFrame.new(-205.789703, 160.413025, 1.48631835)
            wait(1)
            game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", false)
            wait(2)
            Stand.Action = "Summoned"
    end
end)




CreateAction("Mimic", function() 
    local Block = OWNER.Character.BodyEffects:FindFirstChild('Block')
    if OWNER.Character.BodyEffects.Attacking.Value == true then
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-6)
        if STAND.Character:FindFirstChild('Combat') then
            STAND.Character:FindFirstChild('Combat'):Activate()
        else
            STAND.Backpack:FindFirstChild('Combat').Parent = STAND.Character
        end
    elseif Block then
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame * CFrame.new(0,0,-6)
        if not STAND.Character.BodyEffects:FindFirstChild('Block') then
            game:GetService("ReplicatedStorage").MainEvent:FireServer("Block", true)
        end
    else
        if STAND.Character.BodyEffects:FindFirstChild('Block') then
            STAND.Character.BodyEffects:FindFirstChild('Block'):Destroy()
        end
        STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame * CFrame.new(1,1.85,2.5)
    end
end)



--/---------------------------------------------------------------------------------------------\--/ Create & CreateTargetAbility & CreateLoop goes below this :
Create("Mimic!", function() 
    Stand.Action = "Mimic"
end) 

Create("Save!", function ()
    Stand.Action = "Save"
end)

Create("Stab!", function()
Stand.Action = "Stab"
end)

Create("AuraC!", function()
    Stand.Action = "aura1"
end)

Create("Leave!", function() 
    game:Shutdown()
end)

Create("Ora!", function()
    Stand.Action = "Barrage"
end)

Create('Aura!', function()
    Stand.Action = "Aura"
end)

Create('CAura!', function()
    Stand.Action = "AuraC"
end)
Create("Hammer!", function()
    Buy.SledgeHammer() -- Refer to (10)
end)
Create("Sign!", function()
    Buy.StopSign() -- Refer to (10)
end)
Create("Refresh!", function() -- TO RESPAWN YOUR STAND
for i,v in pairs(STAND.Character:GetChildren()) do
if v:IsA("BasePart") then v:Destroy() end end
end)
--Fling function, Fling made by JackMcJagger15, rest of script made by me.
--Currently a Work In Progress. You guys can edit if you want, just re-release it.
--P.S. SET ANTIFLING TO FALSE OR ELSE IT WONT WORK
--Semi works it flings a little
--If stand glitches out say Summon!
CreateTargetAbility("Fling!", function()
    local Target = Stand.Target
    if Target then
    Stand.Action = ""
    repeat wait()
     if Target.Character.BodyEffects["K.O"].Value == false then
    STAND.Character.HumanoidRootPart.CFrame = Target.Character.LowerTorso.CFrame
    wait(0.2)
    local bambam = Instance.new("BodyThrust")
    bambam.Parent = game.Players.LocalPlayer.Character.HumanoidRootPart
    bambam.Force = Vector3.new(500,0,500)
    bambam.Location = game.Players.LocalPlayer.Character.HumanoidRootPart.Position
    wait(7)
    game.Players.LocalPlayer.Charcter.Head:Destroy()
    end
    until Stand.Action == "Summoned" 
    game.Players.LocalPlayer.Charcter.Head:Destroy()
end
end)
--New updated Goto! function
   CreateTargetAbility("Goto!", function()
       local Target = Stand.Target
        if Target then
           Stand.Action = "" 
        repeat wait()
         if OWNER.Character.BodyEffects["K.O"].Value == false then
            Hit(true)
            STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.UpperTorso.CFrame
         elseif OWNER.Character.BodyEffects["K.O"].Value == true then 
             wait(0.5)
             STAND.Character.HumanoidRootPart.CFrame = CFrame.new(OWNER.Character.UpperTorso.Position.X , OWNER.Character.UpperTorso.Position.Y +0.5, OWNER.Character.UpperTorso.Position.Z )
             wait(0.5)
             if STAND.Character.BodyEffects["Grabbed"].Value == nil then
                 wait(0.9)
                 game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", false)
             end
         end
         until Stand.Action == "Summoned" or Target == nil or not OWNER.Character.BodyEffects:FindFirstChild("K.O") or not OWNER.Character.BodyEffects:FindFirstChild("Defense") or STAND.Character.BodyEffects["Grabbed"].Value ~= nil 
         STAND.Character.HumanoidRootPart.CFrame = Target.Character.HumanoidRootPart.CFrame
         wait(1)
         game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", false)
         wait(2)
         Crew(ID)
         Stand.Action = "Summoned"
        end
   end)
 Create("Whip!", function()
    Buy.Nunchucks() -- Refer to (10)
end)
Create("Bat!", function()
    Buy.Bat() -- Refer to (10)
end)
Create("Pencil!", function()
    Buy.Pencil() -- Refer to (10)
end)
Create("Knife!", function()
    Buy.Knife() -- Refer to (10)
end)
Create("Shovel!", function()
    Buy.Shovel() -- Refer to (10)
end)
CreateTargetAbility("Admin-Base!", function() -- someone asked for it
        Chat("Teleporting To Admin-Base!") 
            local Target = Stand.Target
            if Target then
            Hit(true)
            wait(0.6)
            Stand.Action = "" 
            repeat wait()
                if Target.Character.BodyEffects["K.O"].Value == false then
                    Hit(true)
                    STAND.Character.HumanoidRootPart.CFrame = Target.Character.UpperTorso.CFrame
                elseif Target.Character.BodyEffects["K.O"].Value == true then 
                    wait(1)
                    STAND.Character.HumanoidRootPart.CFrame = CFrame.new(Target.Character.UpperTorso.Position.X , Target.Character.UpperTorso.Position.Y +0.5, Target.Character.UpperTorso.Position.Z )
                    wait(.4)
                    if STAND.Character.BodyEffects["Grabbed"].Value == nil then
                        wait(1)
                        game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", false)
                    end
                end
                until Stand.Action == "Summoned" or Target == nil or not Target.Character.BodyEffects:FindFirstChild("K.O") or not Target.Character.BodyEffects:FindFirstChild("Defense") or STAND.Character.BodyEffects["Grabbed"].Value ~= nil 
                STAND.Character.HumanoidRootPart.CFrame = CFrame.new(-872.008, -31.2944, -535.026)
                wait(1)
                game:GetService("ReplicatedStorage").MainEvent:FireServer("Grabbing", false)
                wait(0.5)
                Stand.Action = "Summoned"
                end
end)
    CreateAction("UnderGround", function() 
    STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,0.-11,0)
end)    

Create("UnderGround!", function() -- stand goes underground of course
    Stand.Action = "UnderGround"
end)
CreateAction("DHC", function() 
   STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,0.-11,0)
    DropMoney(10000)
end)    

Create('CAuraU!', function()
    Stand.Action = "DHC"
end)
                                            CreateAction("LeftPOS", function() 
                                                STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(-2,4,3)
                                            end)
                                            
                                            CreateAction("FrontPOS", function() 
                                                STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,1,-6)
                                            end)

                                            CreateAction("MiddlePOS", function() 
                                                STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(0,6,0)
                                            end)

                                            CreateAction("RightPOS", function() 
                                                STAND.Character.HumanoidRootPart.CFrame = OWNER.Character.HumanoidRootPart.CFrame*CFrame.new(2,4,3)
                                            end)
                                            
                                            Create("Left Pos!", function()
                                                Stand.Action = "LeftPOS"
                                            end)
                                            
                                            Create("Front Pos!", function()
                                                Stand.Action = "FrontPOS"
                                            end)

                                            Create("Middle Pos!", function()
                                                Stand.Action = "MiddlePOS"
                                            end)

                                            Create("Right Pos!", function()
                                                Stand.Action = "RightPOS"
                                            end)
Create("Save!", function() 
    Stand.Action = "save"
end) 